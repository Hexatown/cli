﻿Import-Module -Name "$psscriptroot/./modules/PsISEProjectExplorer"

