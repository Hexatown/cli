﻿#TODO: handle $PSScriptRoot paths with spaces
iex "$PSScriptRoot\hexatown.ps1 $($args[0]) $($args[1]) $($args[2]) $($args[3]) $($args[4]) $($args[5]) "