﻿$wc = New-Object System.Net.WebClient
$rss = [xml]$wc.DownloadString('https://www.jumpto365.com/powerbricks/rss.xml')
$feeds =  @()
$Feed = $rss.rss.channel

   ForEach ($msg in $Feed.Item){
   $feeds+= @{

    'LastUpdated' = [datetime]$msg.pubDate

    'displayName' = $msg.description

    'Category' = $msg.category

    'Author' = $msg.author

    'webURl' = $msg.link

   }#EndPSCustomObject

  }#EndForEach



return $rss,($feeds | convertto-json)
