﻿if ($null -eq (get-psdrive | where {$_.Name -eq "HKCR"})){
    New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT
}
Push-Location HKCR:\

$hexatownPath = "hexatown"
$hexatownShell = join-path $hexatownPath "shell"
$hexatownOpen = join-path $hexatownShell "open"
$hexatownCommand = join-path $hexatownOpen "command"

if (!(Test-path $hexatownPath)){  new-item -Path $hexatownPath }
if (!(Test-path $hexatownShell)){  new-item -Path $hexatownShell }
if (!(Test-path $hexatownOpen)){  new-item -Path $hexatownOpen }
if (!(Test-path $hexatownCommand)){  new-item -Path $hexatownCommand }

Set-ItemProperty -Path $hexatownPath -Name "URL Protocol" -Value  ""
Set-Item -Path $hexatownCommand -Value  "xx"




    #-PropertyType DWORD -Force | Out-Null