﻿(get-psdrive | where {$_.Name -eq "Name"})
exit
if ($null -eq (get-psdrive | where {$_.Name -eq "Name"})){
    New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT
}
set-location hkcr
#$REGPATH = "HKCR:\"
#Get-ChildItem "$REGPATH" | Select-Object -ExpandProperty Property 